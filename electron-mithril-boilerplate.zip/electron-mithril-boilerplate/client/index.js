import m from 'mithril';
import { MainView } from './MainView';

m.mount(document.body, MainView);
